"""주식·ETF perp 유니버스 — 워치리스트와 포커스 종목 검증의 기준.

`scripts/fetch_vision.py` 의 STOCK_PRESET 에서 **주식이 아닌 것**(NXPC·SPX 같은
코인)을 뺀 36개다. 순서는 묶음별로 그대로 두어 워치리스트가 같은 순서로 그려진다.

순수 상수 모듈이다 — 설정도 네트워크도 끌어오지 않는다. 그래야 테스트가
임포트만으로 목록을 고정할 수 있다.
"""

from __future__ import annotations

# 묶음 순서를 그대로 유지한다 (docs/15 1-1: 워치리스트는 이 순서로 그린다)
STOCK_PERPS: tuple[str, ...] = (
    # 반도체 — SOXL 과 같은 바구니
    "SOXLUSDT", "SOXSUSDT", "SMHUSDT", "NVDAUSDT", "AMDUSDT", "INTCUSDT",
    "SMCIUSDT", "PANWUSDT", "SNDKUSDT",
    # 지수 ETF (레버리지 없음)
    "SPYUSDT", "QQQUSDT", "IWMUSDT", "DIAUSDT",
    # 대형 기술주
    "AAPLUSDT", "MSFTUSDT", "GOOGLUSDT", "AMZNUSDT", "METAUSDT", "TSLAUSDT",
    "NFLXUSDT", "IBMUSDT", "SHOPUSDT", "UBERUSDT", "HPEUSDT",
    # 기타
    "MSTRUSDT", "COINUSDT", "GMEUSDT", "PLTRUSDT", "DKNGUSDT", "EBAYUSDT",
    "COSTUSDT", "WMTUSDT", "LLYUSDT", "UNHUSDT",
    # 원자재 ETF
    "GLDUSDT", "GDXUSDT",
)

# STOCK_PRESET 에 섞여 있던 코인 — 여기 없다는 것을 테스트가 확인한다
NOT_STOCKS: frozenset[str] = frozenset({"BTCUSDT", "SPXUSDT", "NXPCUSDT"})

# 레버리지 ETF 배율 표시. 목록에 없으면 워치리스트의 lev_tag 는 null 이다.
# (TQQQ·SQQQ·TZA·UVXY 는 지금 유니버스 밖이지만 태그는 미리 둔다 — 종목을 추가할 때
#  태그를 빠뜨리는 실수를 막기 위해서다)
LEVERAGE_TAG: dict[str, str] = {
    "SOXLUSDT": "3x", "SOXSUSDT": "-3x",
    "TQQQUSDT": "3x", "SQQQUSDT": "-3x",
    "TNAUSDT": "3x", "TZAUSDT": "-3x",
    "SPXLUSDT": "3x", "SPXSUSDT": "-3x",
    "UPROUSDT": "3x", "SPXUUSDT": "-3x",
    "UVXYUSDT": "1.5x",
}

_STOCK_SET = frozenset(STOCK_PERPS)


def is_stock_perp(symbol: str | None) -> bool:
    return bool(symbol) and str(symbol).upper() in _STOCK_SET


def leverage_tag(symbol: str) -> str | None:
    return LEVERAGE_TAG.get(str(symbol).upper())


def underlying_ticker(symbol: str) -> str:
    """perp 심볼 → 본주 티커. `TH_UNDERLYING_MAP` 에 없을 때의 기본 규칙(USDT 떼기)."""
    s = str(symbol).upper()
    return s[:-4] if s.endswith("USDT") else s
